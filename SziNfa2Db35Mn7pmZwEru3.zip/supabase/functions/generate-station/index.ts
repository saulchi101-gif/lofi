import { corsHeaders } from '../_shared/cors.ts';

const GENRES = [
  'Lofi Phonk',
  'Phonk',
  'Bass House',
  'Trap',
  'Dubstep',
  'Future Bass',
  'Drum & Bass',
  'Neurofunk',
  'Bass Music',
  'UK Garage',
  'Brazilian Phonk',
  'Memphis Phonk',
  'Drift Phonk',
  'Riddim',
  'Melodic Dubstep',
  'Hybrid Trap',
  'Wave',
  'Jersey Club',
  'Breakbeat',
  'Hardwave'
];

const MOODS = [
  'heavy bass',
  'skull-rattling',
  'intense',
  'powerful',
  'dark & gritty',
  'aggressive',
  'euphoric',
  'groovy bass',
  'bouncy',
  'hard-hitting',
  'underground',
  'menacing',
  'hypnotic',
  'distorted',
  'raw energy',
  'cinematic bass',
  'evil',
  'atmospheric bass'
];

const STREAM_URLS = [
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
];

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const baseUrl = Deno.env.get('ONSPACE_AI_BASE_URL');
    const apiKey = Deno.env.get('ONSPACE_AI_API_KEY');

    if (!baseUrl || !apiKey) {
      throw new Error('OnSpace AI configuration missing');
    }

    // Get random genre and mood
    const genre = GENRES[Math.floor(Math.random() * GENRES.length)];
    const mood = MOODS[Math.floor(Math.random() * MOODS.length)];

    console.log(`Generating station: ${genre} - ${mood}`);

    // Generate station details using AI
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'user',
            content: `Generate a creative DJ station name and short atmospheric description (max 15 words) for a ${genre} station with a ${mood} vibe. CRITICAL: Feature MAXIMUM BASS, sub-bass frequencies, and skull-shaking low-end. Format: NAME | DESCRIPTION. Be bold, raw, and unapologetic. Think underground bass culture.`
          }
        ],
        temperature: 1.2,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OnSpace AI: ${errorText}`);
    }

    const data = await response.json();
    const aiText = data.choices[0]?.message?.content || '';
    
    // Parse AI response
    let stationName = `${genre} Station`;
    let description = `A ${mood} journey through ${genre.toLowerCase()} soundscapes`;

    if (aiText.includes('|')) {
      const parts = aiText.split('|');
      stationName = parts[0].trim();
      description = parts[1]?.trim() || description;
    } else {
      stationName = aiText.split('\n')[0].trim() || stationName;
    }

    // Select random stream URL
    const streamUrl = STREAM_URLS[Math.floor(Math.random() * STREAM_URLS.length)];

    const station = {
      id: crypto.randomUUID(),
      name: stationName,
      description: description,
      genre: genre,
      mood: mood,
      streamUrl: streamUrl,
      duration: 300 + Math.floor(Math.random() * 180), // 5-8 minutes
      generatedAt: new Date().toISOString(),
    };

    console.log('Generated station:', station);

    return new Response(
      JSON.stringify(station),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );

  } catch (error) {
    console.error('Error generating station:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Failed to generate station' 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  }
});
