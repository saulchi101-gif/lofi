// Ad Service for revenue generation
// Note: This uses Google AdMob - requires setup in Google AdMob console

export const AD_CONFIG = {
  // Test Ad Unit IDs - Replace with real IDs from AdMob console
  banner: {
    ios: 'ca-app-pub-3940256099942544/2934735716', // Test ID
    android: 'ca-app-pub-3940256099942544/6300978111', // Test ID
  },
  interstitial: {
    ios: 'ca-app-pub-3940256099942544/4411468910', // Test ID
    android: 'ca-app-pub-3940256099942544/1033173712', // Test ID
  },
};

export const getAdUnitId = (type: 'banner' | 'interstitial', platform: string): string => {
  return AD_CONFIG[type][platform as 'ios' | 'android'] || AD_CONFIG[type].android;
};

// Interstitial ad frequency - show every N tracks
export const INTERSTITIAL_FREQUENCY = 3;

export const shouldShowInterstitial = (trackCount: number): boolean => {
  return trackCount % INTERSTITIAL_FREQUENCY === 0 && trackCount > 0;
};
