import { getSupabaseClient } from '../template';
import { MusicStation } from './lofiService';
import { FunctionsHttpError } from '@supabase/supabase-js';

const supabase = getSupabaseClient();

export const generateNewStation = async (): Promise<{ data: MusicStation | null; error: string | null }> => {
  try {
    const { data, error } = await supabase.functions.invoke('generate-station');

    if (error) {
      let errorMessage = error.message;
      if (error instanceof FunctionsHttpError) {
        try {
          const statusCode = error.context?.status ?? 500;
          const textContent = await error.context?.text();
          errorMessage = `[Code: ${statusCode}] ${textContent || error.message || 'Unknown error'}`;
        } catch {
          errorMessage = `${error.message || 'Failed to read response'}`;
        }
      }
      console.error('Error generating station:', errorMessage);
      return { data: null, error: errorMessage };
    }

    return { data: data as MusicStation, error: null };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Failed to generate station';
    console.error('Error in generateNewStation:', errorMessage);
    return { data: null, error: errorMessage };
  }
};

// Fallback station generator (if AI fails)
export const generateFallbackStation = (): MusicStation => {
  const genres = ['Lofi Hip Hop', 'Synthwave', 'Chillwave', 'Ambient Techno'];
  const moods = ['relaxing', 'focused', 'dreamy', 'energetic'];
  const streams = [
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  ];

  const genre = genres[Math.floor(Math.random() * genres.length)];
  const mood = moods[Math.floor(Math.random() * moods.length)];

  return {
    id: crypto.randomUUID(),
    name: `${genre} Station`,
    description: `A ${mood} journey through ${genre.toLowerCase()}`,
    genre,
    mood,
    streamUrl: streams[Math.floor(Math.random() * streams.length)],
    duration: 300,
    generatedAt: new Date().toISOString(),
  };
};
