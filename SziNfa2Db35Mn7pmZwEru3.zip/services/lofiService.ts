// AI-Generated Music Stations
export interface MusicStation {
  id: string;
  name: string;
  description: string;
  genre: string;
  mood: string;
  streamUrl: string;
  duration: number;
  generatedAt: string;
}

// Legacy interface for compatibility
export interface LofiTrack {
  id: string;
  title: string;
  artist: string;
  uri: string;
  duration: number;
}

// Convert station to track format
export const stationToTrack = (station: MusicStation): LofiTrack => {
  return {
    id: station.id,
    title: station.name,
    artist: `${station.genre} • ${station.mood}`,
    uri: station.streamUrl,
    duration: station.duration,
  };
};
