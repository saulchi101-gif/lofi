import { useState, useEffect, useRef } from 'react';
import { Audio } from 'expo-av';
import { LofiTrack, MusicStation, stationToTrack } from '../services/lofiService';
import { generateNewStation, generateFallbackStation } from '../services/stationService';

export const useLofiPlayer = () => {
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStation, setCurrentStation] = useState<MusicStation | null>(null);
  const [currentTrack, setCurrentTrack] = useState<LofiTrack | null>(null);
  const [volume, setVolume] = useState(0.7);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [trackCount, setTrackCount] = useState(0);
  const [isLoadingStation, setIsLoadingStation] = useState(false);
  const positionUpdateInterval = useRef<NodeJS.Timeout | null>(null);

  // Configure audio mode
  useEffect(() => {
    const configureAudio = async () => {
      try {
        await Audio.setAudioModeAsync({
          playsInSilentModeIOS: true,
          staysActiveInBackground: true,
          shouldDuckAndroid: true,
        });
      } catch (error) {
        console.error('Error configuring audio:', error);
      }
    };
    configureAudio();
  }, []);

  // Load new station
  const loadNewStation = async (autoPlay: boolean = false) => {
    setIsLoadingStation(true);
    try {
      // Generate new station using AI
      const { data: station, error } = await generateNewStation();
      
      const newStation = station || generateFallbackStation();
      const track = stationToTrack(newStation);

      // Unload previous sound
      if (sound) {
        await sound.unloadAsync();
      }

      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: track.uri },
        { shouldPlay: autoPlay || isPlaying, volume },
        onPlaybackStatusUpdate
      );

      setSound(newSound);
      setCurrentStation(newStation);
      setCurrentTrack(track);
      
      if (error) {
        console.log('Using fallback station due to:', error);
      }
    } catch (error) {
      console.error('Error loading station:', error);
      // Use fallback
      const fallbackStation = generateFallbackStation();
      const track = stationToTrack(fallbackStation);
      setCurrentStation(fallbackStation);
      setCurrentTrack(track);
    } finally {
      setIsLoadingStation(false);
    }
  };

  // Playback status update
  const onPlaybackStatusUpdate = (status: any) => {
    if (status.isLoaded) {
      setPosition(status.positionMillis);
      setDuration(status.durationMillis || 0);
      
      if (status.didJustFinish) {
        handleNext();
      }
    }
  };

  // Play/Pause
  const togglePlayPause = async () => {
    if (!sound || !currentTrack) {
      await loadNewStation(true);
      setIsPlaying(true);
      return;
    }

    try {
      if (isPlaying) {
        await sound.pauseAsync();
        setIsPlaying(false);
      } else {
        await sound.playAsync();
        setIsPlaying(true);
      }
    } catch (error) {
      console.error('Error toggling playback:', error);
    }
  };

  // Next station (generate new AI station)
  const handleNext = async () => {
    setTrackCount(prev => prev + 1);
    await loadNewStation(isPlaying);
  };

  // Previous station (generate new AI station)
  const handlePrevious = async () => {
    await loadNewStation(isPlaying);
  };

  // Change volume
  const changeVolume = async (newVolume: number) => {
    setVolume(newVolume);
    if (sound) {
      try {
        await sound.setVolumeAsync(newVolume);
      } catch (error) {
        console.error('Error changing volume:', error);
      }
    }
  };

  // Cleanup
  useEffect(() => {
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
      if (positionUpdateInterval.current) {
        clearInterval(positionUpdateInterval.current);
      }
    };
  }, [sound]);

  // Load initial station
  useEffect(() => {
    loadNewStation(false);
  }, []);

  return {
    isPlaying,
    currentTrack,
    currentStation,
    volume,
    position,
    duration,
    trackCount,
    isLoadingStation,
    togglePlayPause,
    handleNext,
    handlePrevious,
    changeVolume,
  };
};
