import React from 'react';
import { View, Text, StyleSheet, useColorScheme, ActivityIndicator } from 'react-native';
import { LofiTrack, MusicStation } from '../../services/lofiService';
import { colors, spacing, typography, borderRadius } from '../../constants/theme';

interface TrackInfoProps {
  track: LofiTrack | null;
  station?: MusicStation | null;
  isLoading?: boolean;
}

export const TrackInfo: React.FC<TrackInfoProps> = ({ track, station, isLoading }) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? colors.dark : colors.light;

  const styles = StyleSheet.create({
    container: {
      alignItems: 'center',
      paddingHorizontal: spacing.xl,
      gap: spacing.xs,
      minHeight: 100,
      justifyContent: 'center',
    },
    title: {
      fontSize: typography.sizes.xl,
      fontWeight: typography.weights.semibold,
      color: theme.text,
      textAlign: 'center',
    },
    artist: {
      fontSize: typography.sizes.md,
      color: theme.textSecondary,
      textAlign: 'center',
    },
    description: {
      fontSize: typography.sizes.sm,
      color: theme.textSecondary,
      textAlign: 'center',
      fontStyle: 'italic',
      marginTop: spacing.xs,
      opacity: 0.8,
    },
    badge: {
      flexDirection: 'row',
      gap: spacing.sm,
      marginTop: spacing.sm,
    },
    genreBadge: {
      paddingHorizontal: spacing.md,
      paddingVertical: spacing.xs,
      backgroundColor: theme.primary,
      borderRadius: borderRadius.sm,
    },
    genreText: {
      fontSize: typography.sizes.xs,
      color: theme.background,
      fontWeight: typography.weights.semibold,
    },
  });

  if (isLoading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color={theme.primary} />
        <Text style={styles.artist}>Generating new station...</Text>
      </View>
    );
  }

  if (!track) {
    return (
      <View style={styles.container}>
        <Text style={styles.artist}>No station loaded</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{track.title}</Text>
      <Text style={styles.artist}>{track.artist}</Text>
      {station && (
        <>
          <Text style={styles.description}>{station.description}</Text>
          <View style={styles.badge}>
            <View style={styles.genreBadge}>
              <Text style={styles.genreText}>DJ SOUL</Text>
            </View>
          </View>
        </>
      )}
    </View>
  );
};
