import React, { useState } from 'react';
import { View, StyleSheet, useColorScheme, PanResponder, Animated } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing } from '../../constants/theme';

interface VolumeControlProps {
  volume: number;
  onVolumeChange: (volume: number) => void;
}

export const VolumeControl: React.FC<VolumeControlProps> = ({ volume, onVolumeChange }) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? colors.dark : colors.light;
  const [sliderWidth, setSliderWidth] = useState(0);

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: (evt) => {
      const locationX = evt.nativeEvent.locationX;
      const newVolume = Math.max(0, Math.min(1, locationX / sliderWidth));
      onVolumeChange(newVolume);
    },
    onPanResponderMove: (evt) => {
      const locationX = evt.nativeEvent.locationX;
      const newVolume = Math.max(0, Math.min(1, locationX / sliderWidth));
      onVolumeChange(newVolume);
    },
  });

  const styles = StyleSheet.create({
    container: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: spacing.xl,
      gap: spacing.md,
    },
    sliderContainer: {
      flex: 1,
      height: 40,
      justifyContent: 'center',
    },
    sliderTrack: {
      height: 4,
      backgroundColor: theme.border,
      borderRadius: 2,
      overflow: 'hidden',
    },
    sliderFill: {
      height: '100%',
      backgroundColor: theme.primary,
    },
    sliderThumb: {
      position: 'absolute',
      width: 16,
      height: 16,
      borderRadius: 8,
      backgroundColor: theme.primary,
      top: '50%',
      marginTop: -8,
      shadowColor: theme.shadow,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 1,
      shadowRadius: 4,
      elevation: 3,
    },
  });

  return (
    <View style={styles.container}>
      <Ionicons name="volume-low" size={20} color={theme.textSecondary} />
      <View
        style={styles.sliderContainer}
        onLayout={(e) => setSliderWidth(e.nativeEvent.layout.width)}
        {...panResponder.panHandlers}
      >
        <View style={styles.sliderTrack}>
          <View style={[styles.sliderFill, { width: `${volume * 100}%` }]} />
        </View>
        <View style={[styles.sliderThumb, { left: `${volume * 100}%`, marginLeft: -8 }]} />
      </View>
      <Ionicons name="volume-high" size={20} color={theme.textSecondary} />
    </View>
  );
};
