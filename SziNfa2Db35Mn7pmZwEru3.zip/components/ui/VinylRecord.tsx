import React, { useEffect } from 'react';
import { View, StyleSheet, useColorScheme } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSpring,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/theme';

interface VinylRecordProps {
  isPlaying: boolean;
  size?: number;
}

export const VinylRecord: React.FC<VinylRecordProps> = ({ isPlaying, size = 280 }) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? colors.dark : colors.light;
  
  const rotation = useSharedValue(0);
  const tonearmAngle = useSharedValue(-25);

  useEffect(() => {
    if (isPlaying) {
      rotation.value = withRepeat(
        withTiming(360, {
          duration: 4000,
          easing: Easing.linear,
        }),
        -1
      );
      tonearmAngle.value = withSpring(0, {
        damping: 15,
        stiffness: 80,
      });
    } else {
      rotation.value = withTiming(rotation.value, { duration: 800, easing: Easing.out(Easing.cubic) });
      tonearmAngle.value = withSpring(-25, {
        damping: 15,
        stiffness: 80,
      });
    }
  }, [isPlaying]);

  const vinylAnimatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${rotation.value}deg` }],
    };
  });

  const tonearmAnimatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ rotate: `${tonearmAngle.value}deg` }],
    };
  });

  const woodColors = isDark 
    ? ['#3D2817', '#5C3D2E', '#3D2817']
    : ['#8B5A3C', '#A0724E', '#8B5A3C'];

  const styles = StyleSheet.create({
    container: {
      width: size * 1.3,
      height: size * 1.2,
      justifyContent: 'center',
      alignItems: 'center',
    },
    turntableBase: {
      width: size * 1.3,
      height: size * 1.2,
      borderRadius: 16,
      overflow: 'hidden',
      shadowColor: theme.shadow,
      shadowOffset: { width: 0, height: 12 },
      shadowOpacity: 0.3,
      shadowRadius: 20,
      elevation: 15,
    },
    innerBase: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: size * 0.1,
    },
    platter: {
      width: size + 20,
      height: size + 20,
      borderRadius: (size + 20) / 2,
      backgroundColor: isDark ? '#2A2A2A' : '#3A3A3A',
      justifyContent: 'center',
      alignItems: 'center',
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.4,
      shadowRadius: 12,
      elevation: 8,
      borderWidth: 3,
      borderColor: isDark ? '#1A1A1A' : '#2A2A2A',
    },
    vinyl: {
      width: size,
      height: size,
      borderRadius: size / 2,
      backgroundColor: '#1a1a1a',
      justifyContent: 'center',
      alignItems: 'center',
      overflow: 'hidden',
    },
    vinylShine: {
      position: 'absolute',
      width: '100%',
      height: '100%',
      borderRadius: size / 2,
    },
    label: {
      width: size * 0.45,
      height: size * 0.45,
      borderRadius: (size * 0.45) / 2,
      backgroundColor: theme.primary,
      justifyContent: 'center',
      alignItems: 'center',
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 4,
      elevation: 4,
      borderWidth: 1,
      borderColor: 'rgba(255, 255, 255, 0.1)',
    },
    center: {
      width: size * 0.08,
      height: size * 0.08,
      borderRadius: (size * 0.08) / 2,
      backgroundColor: '#C0C0C0',
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.5,
      shadowRadius: 2,
      elevation: 2,
      borderWidth: 1,
      borderColor: '#A0A0A0',
    },
    groove: {
      position: 'absolute',
      borderWidth: 1,
      borderColor: 'rgba(255, 255, 255, 0.03)',
      borderRadius: 9999,
    },
    tonearmContainer: {
      position: 'absolute',
      top: size * 0.1,
      right: size * 0.15,
      width: size * 0.4,
      height: size * 0.6,
      alignItems: 'flex-end',
    },
    tonearmPivot: {
      width: 16,
      height: 16,
      borderRadius: 8,
      backgroundColor: isDark ? '#4A4A4A' : '#6A6A6A',
      justifyContent: 'center',
      alignItems: 'center',
      shadowColor: '#000000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.3,
      shadowRadius: 3,
      elevation: 3,
    },
    tonearmPivotInner: {
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor: '#8A8A8A',
    },
    tonearm: {
      position: 'absolute',
      top: 8,
      right: 8,
      width: size * 0.35,
      height: 4,
      backgroundColor: isDark ? '#5A5A5A' : '#7A7A7A',
      borderRadius: 2,
      transformOrigin: 'right center',
      shadowColor: '#000000',
      shadowOffset: { width: -2, height: 2 },
      shadowOpacity: 0.4,
      shadowRadius: 4,
      elevation: 4,
    },
    tonearmHead: {
      position: 'absolute',
      left: -8,
      top: -4,
      width: 12,
      height: 12,
      backgroundColor: isDark ? '#6A6A6A' : '#8A8A8A',
      borderRadius: 6,
      shadowColor: '#000000',
      shadowOffset: { width: -1, height: 1 },
      shadowOpacity: 0.4,
      shadowRadius: 2,
      elevation: 3,
    },
    needle: {
      position: 'absolute',
      left: -2,
      top: 2,
      width: 2,
      height: 8,
      backgroundColor: '#C0C0C0',
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.turntableBase}>
        <LinearGradient
          colors={woodColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.innerBase}
        >
          {/* Platter */}
          <View style={styles.platter}>
            <Animated.View style={[styles.vinyl, vinylAnimatedStyle]}>
              {/* Vinyl shine effect */}
              <LinearGradient
                colors={[
                  'rgba(255, 255, 255, 0.1)',
                  'transparent',
                  'rgba(255, 255, 255, 0.05)',
                ]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.vinylShine}
              />
              
              {/* Vinyl grooves */}
              {[0.95, 0.88, 0.81, 0.74, 0.67, 0.6, 0.53].map((scale, index) => (
                <View
                  key={index}
                  style={[
                    styles.groove,
                    {
                      width: size * scale,
                      height: size * scale,
                    },
                  ]}
                />
              ))}
              
              {/* Center label */}
              <View style={styles.label}>
                <View style={styles.center} />
              </View>
            </Animated.View>
          </View>

          {/* Tonearm */}
          <View style={styles.tonearmContainer}>
            <View style={styles.tonearmPivot}>
              <View style={styles.tonearmPivotInner} />
            </View>
            <Animated.View style={[styles.tonearm, tonearmAnimatedStyle]}>
              <View style={styles.tonearmHead}>
                <View style={styles.needle} />
              </View>
            </Animated.View>
          </View>
        </LinearGradient>
      </View>
    </View>
  );
};
