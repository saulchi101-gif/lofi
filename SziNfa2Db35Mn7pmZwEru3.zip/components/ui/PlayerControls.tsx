import React from 'react';
import { View, TouchableOpacity, StyleSheet, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing } from '../../constants/theme';

interface PlayerControlsProps {
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
}

export const PlayerControls: React.FC<PlayerControlsProps> = ({
  isPlaying,
  onPlayPause,
  onNext,
  onPrevious,
}) => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? colors.dark : colors.light;

  const styles = StyleSheet.create({
    container: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: spacing.lg,
    },
    button: {
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: theme.surface,
      justifyContent: 'center',
      alignItems: 'center',
      shadowColor: theme.shadow,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 1,
      shadowRadius: 12,
      elevation: 5,
    },
    playButton: {
      width: 72,
      height: 72,
      borderRadius: 36,
      backgroundColor: theme.primary,
    },
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={onPrevious}>
        <Ionicons name="play-skip-back" size={24} color={theme.text} />
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.playButton]} onPress={onPlayPause}>
        <Ionicons 
          name={isPlaying ? 'pause' : 'play'} 
          size={32} 
          color={theme.background} 
        />
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={onNext}>
        <Ionicons name="play-skip-forward" size={24} color={theme.text} />
      </TouchableOpacity>
    </View>
  );
};
