import React, { useState } from 'react';
import { View, Text, StyleSheet, Platform, useColorScheme } from 'react-native';
import { colors, spacing, typography } from '../../constants/theme';

// Note: For production, install and use react-native-google-mobile-ads
// This is a placeholder component showing where ads will appear

export const AdBanner: React.FC = () => {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? colors.dark : colors.light;
  const [adLoaded, setAdLoaded] = useState(false);

  const styles = StyleSheet.create({
    container: {
      height: 50,
      backgroundColor: theme.surface,
      borderTopWidth: 1,
      borderTopColor: theme.border,
      justifyContent: 'center',
      alignItems: 'center',
    },
    placeholder: {
      fontSize: typography.sizes.xs,
      color: theme.textSecondary,
      opacity: 0.5,
    },
  });

  // TODO: Implement real AdMob banner
  // Installation: npx expo install react-native-google-mobile-ads
  // Setup: Configure AdMob in app.json and Google AdMob console
  // Implementation example:
  /*
  import { BannerAd, BannerAdSize, TestIds } from 'react-native-google-mobile-ads';
  
  const adUnitId = __DEV__ 
    ? TestIds.BANNER 
    : Platform.OS === 'ios' 
      ? 'ca-app-pub-xxxxx/xxxxx'  // Your iOS Ad Unit ID
      : 'ca-app-pub-xxxxx/xxxxx'; // Your Android Ad Unit ID

  return (
    <BannerAd
      unitId={adUnitId}
      size={BannerAdSize.BANNER}
      requestOptions={{ requestNonPersonalizedAdsOnly: true }}
      onAdLoaded={() => setAdLoaded(true)}
    />
  );
  */

  return (
    <View style={styles.container}>
      <Text style={styles.placeholder}>
        AD SPACE - Configure AdMob for revenue
      </Text>
    </View>
  );
};
