import React from 'react';
import { View, StyleSheet, useColorScheme, Platform, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useLofiPlayer } from '../hooks/useLofiPlayer';
import { VinylRecord } from '../components/ui/VinylRecord';
import { PlayerControls } from '../components/ui/PlayerControls';
import { VolumeControl } from '../components/ui/VolumeControl';
import { TrackInfo } from '../components/ui/TrackInfo';
import { AdBanner } from '../components/ui/AdBanner';
import { colors, spacing } from '../constants/theme';

export default function LofiPlayer() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const theme = isDark ? colors.dark : colors.light;
  const insets = useSafeAreaInsets();

  const {
    isPlaying,
    currentTrack,
    currentStation,
    volume,
    isLoadingStation,
    togglePlayPause,
    handleNext,
    handlePrevious,
    changeVolume,
  } = useLofiPlayer();

  const gradientColors = isDark
    ? ['#0A0015', '#1A0A2E', '#0F0A1E', '#0A0015']
    : ['#1A0A2E', '#2D1B4E', '#1A0A2E'];

  const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    content: {
      flex: 1,
      paddingTop: insets.top,
      paddingBottom: Platform.select({
        ios: insets.bottom,
        android: spacing.md,
        default: spacing.md,
      }),
    },
    centerSection: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      gap: spacing.xxl,
    },
    controlsSection: {
      gap: spacing.xl,
      paddingBottom: spacing.lg,
    },
    star: {
      position: 'absolute',
      width: 2,
      height: 2,
      backgroundColor: '#FFFFFF',
      borderRadius: 1,
    },
  });

  const stars = Array.from({ length: 100 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    top: Math.random() * 100,
    opacity: Math.random() * 0.8 + 0.2,
    size: Math.random() * 2 + 1,
  }));

  return (
    <View style={styles.container}>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      
      <LinearGradient colors={gradientColors} style={styles.container}>
        {/* Stars */}
        {stars.map((star) => (
          <View
            key={star.id}
            style={[
              styles.star,
              {
                left: `${star.left}%`,
                top: `${star.top}%`,
                opacity: star.opacity,
                width: star.size,
                height: star.size,
                borderRadius: star.size / 2,
              },
            ]}
          />
        ))}
        <View style={styles.content}>
          {/* Main content */}
          <View style={styles.centerSection}>
            <VinylRecord isPlaying={isPlaying && !isLoadingStation} size={240} />
            <TrackInfo 
              track={currentTrack} 
              station={currentStation}
              isLoading={isLoadingStation}
            />
          </View>

          {/* Controls */}
          <View style={styles.controlsSection}>
            <PlayerControls
              isPlaying={isPlaying}
              onPlayPause={togglePlayPause}
              onNext={handleNext}
              onPrevious={handlePrevious}
            />
            <VolumeControl volume={volume} onVolumeChange={changeVolume} />
          </View>
        </View>

        {/* Ad Banner */}
        <AdBanner />
      </LinearGradient>
    </View>
  );
}
