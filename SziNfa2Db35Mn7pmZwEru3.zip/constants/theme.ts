export const colors = {
  light: {
    primary: '#9B7EBD',
    secondary: '#D4A5D4',
    accent: '#E8B4BC',
    background: '#F5F1F7',
    surface: '#FFFFFF',
    text: '#2D2D2D',
    textSecondary: '#6B6B6B',
    border: '#E0D5E8',
    shadow: 'rgba(0, 0, 0, 0.08)',
  },
  dark: {
    primary: '#9B7EBD',
    secondary: '#8B6FA3',
    accent: '#C99AA3',
    background: '#1A1625',
    surface: '#2A2235',
    text: '#F5F1F7',
    textSecondary: '#B8A8C9',
    border: '#3D3548',
    shadow: 'rgba(0, 0, 0, 0.3)',
  },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  sm: 8,
  md: 16,
  lg: 24,
  full: 9999,
};

export const typography = {
  sizes: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 20,
    xl: 24,
    xxl: 32,
  },
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },
};
