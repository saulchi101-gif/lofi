import { StyleSheet } from 'react-native';
import { colors, spacing, borderRadius } from './theme';

export const createCommonStyles = (isDark: boolean) => {
  const theme = isDark ? colors.dark : colors.light;
  
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.background,
    },
    center: {
      justifyContent: 'center',
      alignItems: 'center',
    },
    card: {
      backgroundColor: theme.surface,
      borderRadius: borderRadius.md,
      padding: spacing.md,
      shadowColor: theme.shadow,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 1,
      shadowRadius: 8,
      elevation: 3,
    },
    shadow: {
      shadowColor: theme.shadow,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 1,
      shadowRadius: 12,
      elevation: 5,
    },
  });
};
